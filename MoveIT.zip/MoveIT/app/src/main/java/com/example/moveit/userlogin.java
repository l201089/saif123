package com.example.moveit;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class userlogin extends AppCompatActivity {
    private static String ip="192.168.88.1";
    private static String port="1433";

    private static String Classes= "net.sourceforge.jtds.jdbc.Driver";

    private static String database="testDatabase";
    private static String username="testtt";
    private static String password="testtt";
    private static String url = "jdbc:jtds:sqlserver://"+ip+":"+port+"/"+database;

    private Connection connection=null;


    private EditText adminuser;
    private EditText adminpass;
    private TextView tv;
    private String user,pass;
    private Button login;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userlogin);

        ActivityCompat.requestPermissions(this,new String[] {Manifest.permission.INTERNET}, PackageManager.PERMISSION_GRANTED  );

tv=findViewById(R.id.textView1);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        try {
            Class.forName(Classes);
            connection= DriverManager.getConnection(url,username,password);
            tv.setText("Sucess");

        }
        catch(ClassNotFoundException e)
        {
            e.printStackTrace();
            tv.setText("filure");

        } catch (SQLException e) {
            e.printStackTrace();
            tv.setText("filure");
        }


        TextView btn = findViewById(R.id.signup);
        TextView bck3 = findViewById(R.id.bck3);

        adminuser=findViewById(R.id.uname);
        adminpass=findViewById(R.id.upass);
        login=findViewById(R.id.lbtn);


        getSupportActionBar().hide();
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(userlogin.this,Register.class));
            }
        });

        bck3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity( new Intent( userlogin.this , user.class));
            }
        });
    }




   public void userlgn(View view) {
        String user = adminuser.getText().toString();
        String pass = adminpass.getText().toString();


        if (connection != null) {
            Statement statement = null;
            try {
                statement = connection.createStatement();

                //ResultSet resultSet = statement.executeQuery("select tusername from traveller where tusername = '"+user+"' and  tpassword = '"+pass+"' ;");

              //  ResultSet resultSet = statement.executeQuery("select tusername from traveller where tusername = saif123 and  tpassword = saif123 ;");
                //tv.setText(resultSet.toString());
                // while (resultSet.next()){

                   // tv.setText(user);
                ResultSet resultSet = statement.executeQuery("select tusername from traveller where tusername = '"+user+"' and tpassword ='"+pass+"';");
                while (resultSet.next()){
                    tv.setText(resultSet.getString(1));
                }

                if (resultSet == null) {
                    Toast.makeText(userlogin.this, " Incorrect Credential !! ", Toast.LENGTH_SHORT).show();

                } else {
                    Toast.makeText(userlogin.this, " Login Successfull !! ", Toast.LENGTH_SHORT).show();
                    startActivity( new Intent( userlogin.this , user.class));

                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else {
            Toast.makeText(userlogin.this, " Connection Null !! ", Toast.LENGTH_SHORT).show();

        }


}}
