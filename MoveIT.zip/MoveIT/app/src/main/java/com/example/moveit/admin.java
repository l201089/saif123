package com.example.moveit;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;

import android.os.Bundle;
import android.os.TestLooperManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class admin extends AppCompatActivity {

    private EditText adminuser;
    private EditText adminpass;
   private String user="0";
   public String pass="0";
private String user1,pass1;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);
        getSupportActionBar().hide();

        adminuser=findViewById(R.id.adminname);
        adminpass=findViewById(R.id.adminpass);

        TextView bck5 = findViewById(R.id.bck5);
        Button loginbtn = findViewById(R.id.loginbtn);

        bck5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity( new Intent( admin.this, MainActivity.class));
            }
        });

        loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                user1=adminuser.getText().toString();
                pass1=adminpass.getText().toString();
if(user1!=null && pass1!=null)
{
    if(user.equals(user1))
    {
        if(pass.equals(pass1))
        {
            startActivity( new Intent( admin.this , AdminDashboardd.class));
        }
        else
        {
            Toast.makeText(admin.this, " Incorrect Password !! ", Toast.LENGTH_SHORT).show();

        }
    }
    else
    {
        Toast.makeText(admin.this, " Incorrect Username !! ", Toast.LENGTH_SHORT).show();

    }

}
else
{
    Toast.makeText(admin.this, " Incorrect Credentials !! ", Toast.LENGTH_SHORT).show();
}







            }
        });
    }
}