package com.example.moveit;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ViewDatabase extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_database);

        Button service = findViewById(R.id.SP);
        Button routes = findViewById(R.id.Route);
        Button stops = findViewById(R.id.stops);
        Button users = findViewById(R.id.users);
        Button veh = findViewById(R.id.Vehicle);

        service.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity( new Intent( ViewDatabase.this , Serviceprovider.class));


            }
        });

        routes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity( new Intent( ViewDatabase.this , Routes.class));

            }
        });

        stops.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity( new Intent( ViewDatabase.this , Stops.class));

            }
        });

        users.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity( new Intent( ViewDatabase.this , Users.class));

            }
        });

        veh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity( new Intent( ViewDatabase.this , Vehicles.class));

            }
        });


    }
}