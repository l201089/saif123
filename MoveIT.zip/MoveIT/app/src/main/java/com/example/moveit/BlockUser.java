package com.example.moveit;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.app.AlertDialog;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BlockUser extends AppCompatActivity {
    private static String ip="192.168.100.39";
    private static String port="1433";

    private static String Classes= "net.sourceforge.jtds.jdbc.Driver";

    private static String database="testDatabase";
    private static String username="testtt";
    private static String password="testtt";
    private static String url = "jdbc:jtds:sqlserver://"+ip+":"+port+"/"+database;

    private Connection connection=null;



    //private TextView tv;
    //private TextView tv1;
    //private String user,pass;
    //private Button login;
    private EditText blckuser;
    private Button blckbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_block_user);

        Button btnLoad = (Button) findViewById (R.id.tbutton);
        GridView list = (GridView) findViewById(R.id.gridview1);
        blckuser = findViewById(R.id.blockUser);// use for getting username to be deleted
        blckbtn = findViewById(R.id.blockbtn);

        getSupportActionBar().hide();

        ActivityCompat.requestPermissions(this,new String[] {Manifest.permission.INTERNET}, PackageManager.PERMISSION_GRANTED  );

        // tv=findViewById(R.id.textView7);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        try {
            Class.forName(Classes);
            connection= DriverManager.getConnection(url,username,password);
           // tv.setText("Sucess");

        }
        catch(ClassNotFoundException e)
        {
            e.printStackTrace();
           // tv.setText("filure");

        } catch (SQLException e) {
            e.printStackTrace();
         //   tv.setText("filure");
        }

        btnLoad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                List<Map<String,String>> data = new ArrayList<Map<String,String>>();
                if(connection!=null)
                {
                    Statement statement = null;
                    try {
                        statement= connection.createStatement();

                        ResultSet resultSet = statement.executeQuery("select * from traveller");
                        while (resultSet.next()) {
                            //  tv.setText(resultSet.getString(1));
                            Map<String, String> tab = new HashMap<String, String>();
                            tab.put("tusername", resultSet.getString("tusername"));
                            tab.put("temail", resultSet.getString("temail"));
                            tab.put("tpassword", resultSet.getString("tpassword"));
                            data.add(tab);
                        }
                       // tv1.setText(data);

                       String[] from ={"tusername" , "temail" , "tpassword"};
                        int[] to ={R.id.Name , R.id.Email , R.id.Phone};
                        SimpleAdapter adapter = new SimpleAdapter(BlockUser.this, data, R.layout.gridviewlayout, from, to);
                        list.setAdapter(adapter);


                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }

            }

        });

        blckbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                List<Map<String,String>> data = new ArrayList<Map<String,String>>();
                if(connection!=null)
                {
                    String name = blckuser.getText().toString();

                    Statement statement = null;
                    Statement statement2 = null;
                    try {
                        statement= connection.createStatement();
                        statement2 = connection.createStatement();

                        statement.executeQuery("delete from traveller where tusername ='"+name+"';");

                        ResultSet resultSet = statement2.executeQuery("select * from traveller");
                        while (resultSet.next()) {
                            //  tv.setText(resultSet.getString(1));
                            Map<String, String> tab = new HashMap<String, String>();
                            tab.put("tusername", resultSet.getString("tusername"));
                            tab.put("temail", resultSet.getString("temail"));
                            tab.put("tpassword", resultSet.getString("tpassword"));
                            data.add(tab);
                        }
                        // tv1.setText(data);

                        String[] from ={"tusername" , "temail" , "tpassword"};
                        int[] to ={R.id.Name , R.id.Email , R.id.Phone};
                        SimpleAdapter adapter = new SimpleAdapter(BlockUser.this, data, R.layout.gridviewlayout, from, to);
                        list.setAdapter(adapter);


                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }

            }


        });




    }

}


