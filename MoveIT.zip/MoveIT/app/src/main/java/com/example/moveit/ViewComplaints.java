package com.example.moveit;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.Button;
import android.widget.GridView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ViewComplaints extends AppCompatActivity {

    private static String ip = "192.168.100.39";
    private static String port = "1433";

    private static String Classes = "net.sourceforge.jtds.jdbc.Driver";

    private static String database = "testDatabase";
    private static String username = "testtt";
    private static String password = "testtt";
    private static String url = "jdbc:jtds:sqlserver://" + ip + ":" + port + "/" + database;

    private Connection connection = null;


    private TextView tv;
    private TextView tv1;
    private String user, pass;
    private Button login;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_complaints);

        Button btnLoad = (Button) findViewById(R.id.view);
        GridView list = (GridView) findViewById(R.id.gridview2);
//tv1=findViewById(R.id.textView8);


        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.INTERNET}, PackageManager.PERMISSION_GRANTED);

        //tv=findViewById(R.id.textView7);


        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        try {
            Class.forName(Classes);
            connection = DriverManager.getConnection(url, username, password);


        } catch (ClassNotFoundException e) {
            e.printStackTrace();


        } catch (SQLException e) {
            e.printStackTrace();

        }


        // TextView btn = findViewById(R.id.signup);
        //TextView bck3 = findViewById(R.id.bck3);

        //adminuser=findViewById(R.id.uname);
        //adminpass=findViewById(R.id.upass);
        //login=f6indViewById(R.id.lbtn);


        getSupportActionBar().hide();


        btnLoad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                List<Map<String, String>> data = new ArrayList<Map<String, String>>();
                if (connection != null) {
                    Statement statement = null;
                    try {
                        statement = connection.createStatement();

                        ResultSet resultSet = statement.executeQuery("select * from complaints");
                        while (resultSet.next()) {
                            //  tv.setText(resultSet.getString(1));
                            Map<String, String> tab = new HashMap<String, String>();
                            tab.put("complaintID", resultSet.getString("complaintId"));
                            tab.put("tusername", resultSet.getString("tusername"));
                            tab.put("text", resultSet.getString("text"));
                            tab.put("serviceId", resultSet.getString("serviceId"));


                            data.add(tab);
                        }
                        // tv1.setText(data);

                        String[] from = {"complaintID", "tusername", "text", "service"};
                        int[] to = {R.id.complaintID, R.id.userID, R.id.Text, R.id.Service};
                        SimpleAdapter adapter = new SimpleAdapter(ViewComplaints.this, data, R.layout.gridview2, from, to);
                        list.setAdapter(adapter);


                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
             /*  int i = 0;
                while (i < 5) {
                    Map<String, String> tab = new HashMap<String, String>();
                    tab.put("complaintID", "1");
                    tab.put("userID", "saif123");
                    tab.put("text", "bad buses");
                    tab.put("service", "5");


                    data.add(tab);
                    i++;
                }
                    // tv1.setText(data);

                    String[] from = {"complaintID", "userID", "text" , "service" };
                    int[] to = {R.id.complaintID, R.id.userID, R.id.Text , R.id.Service };
                    SimpleAdapter adapter = new SimpleAdapter(ViewComplaints.this, data, R.layout.gridview2, from, to);
                    list.setAdapter(adapter);

                }*/
                }
            }
        });
    }
}