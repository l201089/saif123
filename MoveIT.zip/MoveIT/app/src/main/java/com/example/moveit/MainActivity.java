package com.example.moveit;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


@SuppressLint("SetTextI18n")
public class MainActivity extends AppCompatActivity {

    private TextView textView;

    public String a;
    private static String ip="192.168.100.39";
    private static String port="1433";

    private static String Classes= "net.sourceforge.jtds.jdbc.Driver";

    private static String database="testDatabase";
    private static String username="testtt";
    private static String password="testtt";
    private static String url = "jdbc:jtds:sqlserver://"+ip+":"+port+"/"+database;

    private Connection connection=null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        ActivityCompat.requestPermissions(this,new String[] {Manifest.permission.INTERNET}, PackageManager.PERMISSION_GRANTED  );

        textView = findViewById(R.id.db);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        try {
            Class.forName(Classes);
            connection= DriverManager.getConnection(url,username,password);


        }
        catch(ClassNotFoundException e)
        {
            e.printStackTrace();
            textView.setText("error");
        } catch (SQLException e) {
            e.printStackTrace();
            textView.setText("failure");
        }




        Button btn2 = findViewById(R.id.userButton);
        Button btn3 = findViewById(R.id.adminbutton);
        getSupportActionBar().hide();
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this , user.class ));


            }
        });

        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity( new Intent( MainActivity.this , admin.class));
            }
        });
    }



    public void sqlButton(View view)
    {
        if(connection!=null)
        {
            Statement statement = null;
            try {
                statement= connection.createStatement();

                ResultSet resultSet = statement.executeQuery("select * from a;");
                while (resultSet.next()){
                    textView.setText(resultSet.getString(1));
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        else {
            textView.setText("Connection is null");
        }
    }


}