package com.example.moveit;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



public class AdminPassword extends AppCompatActivity {

    private static String ip="192.168.18.122";
    private static String port="1433";

    private static String Classes= "net.sourceforge.jtds.jdbc.Driver";

    private static String database="testDatabase";
    private static String username="testtt";
    private static String password="testtt";
    private static String url = "jdbc:jtds:sqlserver://"+ip+":"+port+"/"+database;

    private Connection connection=null;



    private TextView p1;
    private TextView p2;
    private String user,pass;
    private Button login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_password);

        Button btnLoad = (Button) findViewById (R.id.resetPass);

        String newPass;
        String confPass;

        p1 = findViewById(R.id.newPass);
        p2 = findViewById(R.id.confPass);

        newPass = p1.getText().toString();
        confPass = p2.getText().toString();



        ActivityCompat.requestPermissions(this,new String[] {Manifest.permission.INTERNET}, PackageManager.PERMISSION_GRANTED  );




        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        try {
            Class.forName(Classes);
            connection= DriverManager.getConnection(url,username,password);


        }
        catch(ClassNotFoundException e)
        {
            e.printStackTrace();


        } catch (SQLException e) {
            e.printStackTrace();

        }

        getSupportActionBar().hide();

        btnLoad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if( newPass != confPass)
                {
                    Toast.makeText(AdminPassword.this, " Password not correct !! ", Toast.LENGTH_SHORT).show();

                }
                else
                {

                    if (connection != null) {
                        Statement statement = null;
                        try {
                            statement = connection.createStatement();

                            ResultSet resultSet = statement.executeQuery("update aaccount set  ");// update ke statement
                            Toast.makeText(AdminPassword.this, " Successfully updated password ", Toast.LENGTH_SHORT).show();




                        } catch (SQLException e) {
                            e.printStackTrace();
                        }

                    }
                }
            }
        });
    }
}
