package com.example.moveit;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class AdminDashboardd extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_dashboard2);

        getSupportActionBar().hide();

        TextView bck6 = findViewById(R.id.bck6);
        bck6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(AdminDashboardd.this, admin.class));
            }

        });


        Button manageUser = findViewById(R.id.manageuser);
        manageUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(AdminDashboardd.this, BlockUser.class));
            }
        });

        Button complaints = findViewById(R.id.button6);
        complaints.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(AdminDashboardd.this, ViewComplaints.class));
            }
        });



    }
}